import java.util.Map;
import java.util.HashMap;

public class ContactService {

	private final Map<String, Contact> contacts = new HashMap<String, Contact>();
	
	public void addContact(Contact contact) {
		if (contacts.containsKey(contact.getContactID())) {
			throw new IllegalArgumentException("couldnt add a contact due to invalid ID, contact ID already in use");
		}
		contacts.put(contact.getContactID(), contact);
	}
	
	public void deleteContact(String contactID) {
		if(!contacts.containsKey(contactID)) {
			throw new IllegalArgumentException("couldnt delete a contact due to invalid ID, contact ID doesnt exist");
		}
		contacts.remove(contactID);
	}
	
	public void updateFirstName(String contactID, String firstName) {
		if (!contacts.containsKey(contactID)) {
			throw new IllegalArgumentException("couldnt update first name due to invalid ID, contact ID doesnt exist");
		}
		contacts.get(contactID).setFirstName(firstName);
	}
	
	public void updateLastName(String contactID, String lastName) {
		if (!contacts.containsKey(contactID)) {
			throw new IllegalArgumentException("couldnt update last name due to invalid ID, contact ID doesnt exist");
		}
		contacts.get(contactID).setLastName(lastName);
	}
	
	public void updatePhoneNumber(String contactID, String phoneNumber) {
		if(!contacts.containsKey(contactID)) {
			throw new IllegalArgumentException("couldnt update phone number due to invalid ID, contact ID doesnt exist");
		}
		contacts.get(contactID).setPhoneNumber(phoneNumber);
	}
	
	public void updateAddress(String contactID, String address) {
		if(!contacts.containsKey(contactID)) {
			throw new IllegalArgumentException("couldnt update address due to invalid ID, contact ID doesnt exist");
		}
		contacts.get(contactID).setAddress(address);
	}
	
	public Contact getContact(String contactID) {
		if(!contacts.containsKey(contactID)) {
			throw new IllegalArgumentException("couldnt get contact information due to invalid ID, contact ID doesnt exist");
		}
		return contacts.get(contactID);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
