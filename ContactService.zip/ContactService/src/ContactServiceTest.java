import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    
    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("00000", "Random", "Testing", "4697320434", "123 Testing Ave");

        service.addContact(contact);
        assertEquals(contact, service.getContact("00000"));
    }

    @Test
    public void testAddDuplicateContact() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("00000", "Random", "Testing", "4697320434", "123 Testing Ave");
        Contact contact2 = new Contact("00000", "John", "Doe", "1234567890", "456 Elm St");

        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact2));
    }

    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("00000", "Random", "Testing", "4697320434", "123 Testing Ave");

        service.addContact(contact);
        service.deleteContact("00000");
        assertThrows(IllegalArgumentException.class, () -> service.getContact("00000"));
    }

    @Test
    public void testDeleteNonExistentContact() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("99999"));
    }

    @Test
    public void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("00000", "Random", "Testing", "4697320434", "123 Testing Ave");

        service.addContact(contact);
        service.updateFirstName("00000", "testfirst");
        assertEquals("testfirst", service.getContact("00000").getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("00000", "Random", "Testing", "4697320434", "123 Testing Ave");

        service.addContact(contact);
        service.updateLastName("00000", "testlast");
        assertEquals("testlast", service.getContact("00000").getlastName());
    }

    @Test
    public void testUpdatePhoneNumber() {
        ContactService service = new ContactService();
        Contact contact = new Contact("00000", "Random", "Testing", "4697320434", "123 Testing Ave");

        service.addContact(contact);
        service.updatePhoneNumber("00000", "9876543210");
        assertEquals("9876543210", service.getContact("00000").getPhoneNumber());
    }

    @Test
    public void testUpdateAddress() {
        ContactService service = new ContactService();
        Contact contact = new Contact("00000", "Random", "Testing", "4697320434", "123 Testing Ave");

        service.addContact(contact);
        service.updateAddress("00000", "789 New St");
        assertEquals("789 New St", service.getContact("00000").address());
    }

    @Test
    public void testUpdateNonExistentContact() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("99999", "NewName"));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("99999", "NewLast"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhoneNumber("99999", "1234567890"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("99999", "New Address"));
    }
}
