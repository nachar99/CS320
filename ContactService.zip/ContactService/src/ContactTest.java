import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
    
    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("00000", "Random", "Testing", "4697320434", "123 Testing Ave");
        assertNotNull(contact);
        assertEquals("00000", contact.getContactID());
        assertEquals("Random", contact.getFirstName());
        assertEquals("Testing", contact.getlastName());
        assertEquals("4697320434", contact.getPhoneNumber());
        assertEquals("123 Testing Ave", contact.address());
    }
    
    @Test
    public void testInvalidContactID() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Random", "Testing", "4697320434", "123 Testing Ave"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "Random", "Testing", "4697320434", "123 Testing Ave"));
    }
    
    @Test
    public void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("00000", null, "Testing", "4697320434", "123 Testing Ave"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("00000", "RandomLongName", "Testing", "4697320434", "123 Testing Ave"));
    }
    
    @Test
    public void testInvalidLastName() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("00000", "Random", null, "4697320434", "123 Testing Ave"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("00000", "Random", "TestingLongName", "4697320434", "123 Testing Ave"));
    }
    
    @Test
    public void testInvalidPhoneNumber() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("00000", "Random", "Testing", null, "123 Testing Ave"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("00000", "Random", "Testing", "123456789", "123 Testing Ave"));
    }
    
    @Test
    public void testInvalidAddress() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("00000", "Random", "Testing", "4697320434", null));
        assertThrows(IllegalArgumentException.class, () -> new Contact("00000", "Random", "Testing", "4697320434", "123 Testing Ave, Apt 101, Springfield, IL"));
    }
    
    @Test
    public void testSetters() {
        Contact contact = new Contact("00000", "Random", "Testing", "4697320434", "123 Testing Ave");
        
        contact.setFirstName("John");
        contact.setLastName("Doe");
        contact.setPhoneNumber("1234567890");
        contact.setAddress("777 nowhere St");
        
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getlastName());
        assertEquals("1234567890", contact.getPhoneNumber());
        assertEquals("777 nowhere St", contact.address());
    }
    
    @Test
    public void testInvalidSetters() {
        Contact contact = new Contact("00000", "Random", "Testing", "4697320434", "123 Testing Ave");
        
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("Johnathan"));
        
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("DoeDoeDoe"));
        
        assertThrows(IllegalArgumentException.class, () -> contact.setPhoneNumber(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhoneNumber("123456789"));
        
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress("455 Best St, Apt 2, Test County, MO"));
    }
}
